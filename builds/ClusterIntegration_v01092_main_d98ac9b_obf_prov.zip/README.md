# Cluster Integration MH2p / PCM5 — Android Auto & CarPlay navigation on the digital cluster

Based on free ModKit by LawPaul [https://lawpaul.github.io/MH2p_SD_ModKit_Site/] that allows for modifying the MH2p unit used in some Volkswagen AG vehicles using only an SD card or flash drive.

Renders **Android Auto** and **CarPlay** navigation directly on the instrument cluster of PCM5 / MH2P Porsche vehicles. Turn-by-turn arrows, live map view, seamless handoff back to native Porsche navigation when the phone disconnects.

This software is free software, developed and maintained in my spare time.

A lot of time goes into reverse engineering, development, testing and supporting different Porsche models and firmware versions.

If you find it useful, please consider supporting continued development.

Donations are entirely optional. The software is free and all features are available without payment. [https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/I2I01UMJL5]

> [**Download** latest release](https://github.com/fifthBro/mh2p-cluster/releases/latest)

> **Website:** https://fifthbro.github.io/

> **Support / Discussion:** ModKit Discord https://discord.gg/QAEkZmDh9

> **Status:** Stable release — CarPlay cluster rendering now live alongside Android Auto.

---

## What it does

When you plug in (or wirelessly connect) your phone, the digital instrument cluster becomes a second navigation display driven by the phone.

- **Android Auto cluster nav** — Google Maps, Waze, and other AA-compatible navigation apps render live in the cluster.
- **CarPlay cluster nav** — Apple Maps, Google Maps, Waze on iPhone stream to the cluster the same way.
- **Turn-by-turn on the physical dial** — maneuver icons, distance to next, lane guidance, roundabout exits, for both platforms.
- **Native maps come back automatically** — when the phone disconnects, the built-in Porsche navigation reclaims the cluster with no reboot required.
- **Independent of HMI state** — you can leave the main head-unit screen on native infotainment; the cluster keeps showing phone nav underneath.
- **Session-stable** — reconnects, park/drive cycles, HMI-off transitions all handled without the mirror dying.

---

## Supported vehicles

| Model | Head unit | Status |
| Cayenne (9Y0) | PCM5 / MH2P | ✅ Supported |
| Macan | PCM5 / MH2P | ✅ Supported |
| Panamera | PCM5 / MH2P | ✅ Supported |
| 992.1 (911) | PCM5 / MH2P | ✅ Supported |
| 718 (Cayman / Boxster) | MHI2 / PCM4 | 🚧 In progress — AA and CarPlay working, release next |

Model years: **2019–2021**. Firmware range: **26xx–29xx**. Other firmwares can be enabled on request via the installer's OEM/firmware gate.

---

## Installation

Uses the **MH2P Mod Kit** (LawPaul): https://lawpaul.github.io/MH2p_SD_ModKit_Site/

> ⚠ **Warning:** This modifies Java files on your PCM5/MH2P unit. Only proceed if you understand the risks.

**Prerequisites**

- Car with PCM5/MH2P head unit
- SD card (FAT32)
- Android Auto or CarPlay compatible phone
- Android Auto [activated](https://lawpaul.github.io/MH2p_SD_ModKit_Site/) on the head unit

**Steps**

1. Download the latest release ZIP
2. Format SD card as FAT32
3. Extract the ZIP to the root of the SD card
4. Start the vehicle
5. Insert the SD card
6. Within a few seconds, the head unit will reboot
7. The update installs automatically
8. When done, a prompt shows "Please remove update media"
9. Remove the SD card
10. Head unit reboots into normal mode with the mod installed

**Uninstall**

1. Rename `uninstall.txt.template` (in the mod folder on the SD card) to `uninstall.txt`
2. Re-run the ModKit update procedure with the SD card
3. `Update/uninstall.sh` runs automatically and restores originals from backup
4. After uninstall completes, remove `uninstall.txt` from the SD so it doesn't re-trigger

---

## Features

- **Full navigation support** — turn arrows, distance, road names, roundabouts, highway exits, lane guidance
- **Real-time updates** — proximity-zone throttling (veryFar → now) with heartbeat to hold the display against native nav
- **Intelligent unit detection** — automatic km/mi and LHD/RHD detection via platform services with JSON country fallback (60+ countries)
- **Multi-car config** — per-car overrides for Cayenne / 911 / Panamera / Macan / (Audi A7)
- **JSON configuration** — runtime-configurable without any reinstall; override via USB/SD card
- **Comprehensive logging** — dual-timestamp log with optional privacy hashing and external USB/SD output
- **Multi-platform** — Android Auto (DSI) + CarPlay (RGI / altScreen) in one integrated mod